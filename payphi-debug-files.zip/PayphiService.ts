import { InteractionManager, NativeModules } from 'react-native';
import type { PaymentGateway } from '../config/paymentGateways';
import { getPayphiCredentials } from '../config/payphiConfig';

/**
 * ICICI PayPhi Customer SDK.
 * - Book-slot supplies `data.icici` (merchantId, amount, txn, …)
 * - HMAC `secretKey` is never required from book-slot; UAT Key comes from payphiConfig
 *   (or backend may send `secureToken` / `secretKey` on `data.icici` later)
 * Flow: setAppInfo → makePayment → payment_response → verify-payment
 */

/** PayPhi HMAC + sheet require amount as "##.##" (rupees). */
const formatPayphiAmount = (raw: unknown): string => {
  if (raw == null || raw === '') return '';
  const cleaned = String(raw)
    .replace(/,/g, '')
    .replace(/₹/g, '')
    .replace(/rs\.?/gi, '')
    .trim();
  const n = Number(cleaned);
  if (!Number.isFinite(n) || n <= 0) return '';
  return n.toFixed(2);
};

const waitForUiIdle = (): Promise<void> =>
  new Promise(resolve => {
    InteractionManager.runAfterInteractions(() => {
      setTimeout(resolve, 120);
    });
  });

export type PayphiEnvironment = 'UAT' | 'PROD' | 'SANDBOX' | string;

export type PayphiAppInfo = {
  merchantId: string;
  appId: string;
  environment: PayphiEnvironment;
  merchantName?: string;
  aggregatorId?: string;
};

/** book-slot `data.icici` (+ optional secretKey if backend adds it) */
export type PayphiPaymentRequest = Record<string, any> & {
  amount: string;
  merchantId: string;
  merchantTxnNo: string;
  currencyCode: string;
  customerEmailID: string;
  secretKey?: string;
  aggregatorID?: string;
  addlParam1?: string;
  addlParam2?: string;
  apiVersion?: string;
};

export type PayphiPaymentResult = {
  status: 'success' | 'failed' | 'cancelled' | 'pending';
  raw: any;
  gatewayOrderId: string;
  gatewayPaymentId: string;
  gatewaySignature: string;
  message: string;
};

export type PayphiHostedCheckout = {
  paymentId: string;
  orderId: string;
  redirectUrl: string;
  returnUrl: string;
};

const pickString = (...values: unknown[]): string => {
  for (const value of values) {
    if (value == null) continue;
    const s = String(value).trim();
    if (s) return s;
  }
  return '';
};

let cachedSdk: any | undefined;

const loadPayphiSdk = (): any => {
  if (cachedSdk !== undefined) return cachedSdk;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require('react-native-payphi-sdk');
    cachedSdk = mod?.default ?? mod?.PayphiSdk ?? mod ?? null;
  } catch {
    cachedSdk = null;
  }
  return cachedSdk;
};

const getNativePayphiModule = () => NativeModules?.PayphiSdk || null;

export const isPayphiNativeLinked = (): boolean => Boolean(getNativePayphiModule());

export const isPayphiSdkAvailable = (): boolean => Boolean(loadPayphiSdk());

/** Raw `data.icici` from book-slot / place-order — do not reshape. */
export const getIciciPayload = (data: any): Record<string, any> | null => {
  const icici = data?.icici;
  if (!icici || typeof icici !== 'object' || Array.isArray(icici)) return null;
  return icici;
};

/**
 * setAppInfo from book-slot `icici`, with UAT config fallback for merchant/app id.
 */
export const parsePayphiAppInfo = (data: any): PayphiAppInfo | null => {
  const creds = getPayphiCredentials();
  const icici = getIciciPayload(data);
  const merchantId = pickString(
    icici?.merchantId,
    icici?.merchant_id,
    creds.merchantId,
  );
  if (!merchantId) return null;

  return {
    merchantId,
    appId: pickString(icici?.appId, icici?.app_id, merchantId) || merchantId,
    environment: normalizePayphiEnv(
      pickString(icici?.environment, icici?.env, creds.environment, 'UAT'),
    ),
    merchantName:
      pickString(icici?.merchantName, icici?.merchant_name, icici?.customerName, 'Ayurmuni') ||
      'Ayurmuni',
    aggregatorId:
      pickString(icici?.aggregatorID, icici?.aggregatorId, creds.aggregatorID) ||
      undefined,
  };
};

/**
 * Pass book-slot `data.icici` through to makePayment (same keys the API returns).
 */
export const parsePayphiPaymentRequest = (
  data: any,
  _fallback?: {
    amount?: number;
    customerName?: string;
    customerEmail?: string;
    customerMobile?: string;
  },
): PayphiPaymentRequest | null => {
  const icici = getIciciPayload(data);
  if (!icici) return null;

  const creds = getPayphiCredentials();
  const merchantId = pickString(
    icici.merchantId,
    icici.merchant_id,
    creds.merchantId,
  );
  const merchantTxnNo = pickString(
    icici.merchantTxnNo,
    icici.merchant_txn_no,
    data?.gateway_order_id,
    data?.icici_merchant_txn_no,
    data?.merchantTxnNo,
  );
  const amount = formatPayphiAmount(
    pickString(
      icici.amount,
      _fallback?.amount != null ? String(_fallback.amount) : '',
    ),
  );
  const customerEmailID = pickString(
    icici.customerEmailID,
    icici.customer_email,
    _fallback?.customerEmail,
  );
  if (!merchantId || !merchantTxnNo || !amount || !customerEmailID) return null;

  // SDK SecureToken = HMAC(amount+currency+merchantId+merchantTxnNo, Key).
  // Prefer explicit secureToken from backend; else UAT Key so native can HMAC.
  // Do NOT use initiateSale `secureHash` here — that hash is for hosted redirect only.
  const secretKey = pickString(
    icici.secretKey,
    icici.secret_key,
    data?.secret_key,
    creds.secretKey,
  );
  const secureToken = pickString(
    icici.secureToken,
    icici.SecureToken,
    data?.secureToken,
  );

  return {
    ...icici,
    amount,
    merchantId,
    merchantTxnNo,
    currencyCode: pickString(icici.currencyCode, icici.currency, '356') || '356',
    customerEmailID,
    customerMobileNo: pickString(icici.customerMobileNo, _fallback?.customerMobile),
    customerName: pickString(icici.customerName, _fallback?.customerName),
    aggregatorID: pickString(
      icici.aggregatorID,
      icici.aggregatorId,
      creds.aggregatorID,
    ),
    addlParam1: pickString(icici.addlParam1),
    addlParam2: pickString(icici.addlParam2),
    apiVersion: pickString(icici.apiVersion, '1.0') || '1.0',
    transactionType: pickString(icici.transactionType, 'SALE') || 'SALE',
    payType: pickString(icici.payType, '0') || '0',
    ...(secretKey ? { secretKey } : {}),
    ...(secureToken ? { secureToken } : {}),
    paymentId: pickString(data?.payment_id),
  };
};

export const summarizeIciciPayload = (data: any) => {
  const icici = getIciciPayload(data);
  const creds = getPayphiCredentials();
  if (!icici) return { hasIcici: false, keys: data ? Object.keys(data) : [] };
  const keys = Object.keys(icici);
  const hasServerSecret = Boolean(icici.secretKey || icici.secret_key);
  const hasSecureToken = Boolean(icici.secureToken || icici.SecureToken);
  return {
    hasIcici: true,
    keys,
    merchantId: Boolean(icici.merchantId || icici.merchant_id),
    merchantTxnNo: Boolean(icici.merchantTxnNo || data?.gateway_order_id),
    amount: Boolean(icici.amount),
    customerEmailID: Boolean(icici.customerEmailID),
    hasSecretKey: hasServerSecret || Boolean(creds.secretKey),
    secretKeySource: hasServerSecret
      ? 'api'
      : creds.secretKey
        ? 'uat_config'
        : 'none',
    hasSecureToken,
  };
};

export const parsePayphiHostedCheckout = (data: any): PayphiHostedCheckout | null => {
  const creds = getPayphiCredentials();
  const icici = getIciciPayload(data) || {};
  const tranCtx = pickString(
    data?.tranCtx,
    data?.tran_ctx,
    icici?.tranCtx,
    icici?.tran_ctx,
  );
  const redirectBase = pickString(
    data?.redirectURI,
    data?.redirect_uri,
    icici?.redirectURI,
    icici?.redirect_uri,
    data?.redirect_url,
    data?.checkout_url,
    data?.payment_url,
    icici?.redirect_url,
    creds.authRedirectBase,
  );
  const redirectUrl = tranCtx
    ? `${redirectBase}${redirectBase.includes('?') ? '&' : '?'}tranCtx=${encodeURIComponent(tranCtx)}`
    : pickString(
        data?.redirect_url,
        data?.checkout_url,
        data?.payment_url,
        icici?.redirect_url,
      );
  const paymentId = pickString(data?.payment_id);
  const orderId = pickString(
    data?.gateway_order_id,
    data?.icici_merchant_txn_no,
    icici?.merchantTxnNo,
    data?.merchantTxnNo,
  );
  if (!paymentId || !orderId || !redirectUrl) return null;
  return {
    paymentId,
    orderId,
    redirectUrl,
    returnUrl: pickString(data?.return_url, data?.callback_url),
  };
};

const classifyPayphiResponse = (raw: any): PayphiPaymentResult['status'] => {
  if (raw?.error) return 'failed';
  const code = pickString(
    raw?.responseCode,
    raw?.response_code,
    raw?.ResponseCode,
    raw?.txnResponseCode,
    raw?.TxnResponseCode,
    raw?.statusCode,
    raw?.code,
  ).toUpperCase();
  const status = pickString(
    raw?.status,
    raw?.payment_status,
    raw?.txnStatus,
    raw?.TxnStatus,
  ).toLowerCase();
  const message = pickString(
    raw?.message,
    raw?.responseMessage,
    raw?.ResponseMessage,
    raw?.error,
  ).toLowerCase();

  if (
    code === 'E000' ||
    code === '000' ||
    status === 'success' ||
    status === 'successful' ||
    status === 'sucess' ||
    status === 'paid' ||
    status === 'completed'
  ) {
    return 'success';
  }
  if (status === 'pending' || status === 'processing' || code === 'R1000') {
    return 'pending';
  }
  if (
    status === 'cancel' ||
    status === 'cancelled' ||
    status === 'canceled' ||
    message.includes('cancel') ||
    message.includes('closed by user')
  ) {
    return 'cancelled';
  }
  return 'failed';
};

export const mapPayphiResponse = (raw: any): PayphiPaymentResult => {
  const status = classifyPayphiResponse(raw);
  return {
    status,
    raw,
    gatewayOrderId: pickString(
      raw?.MerchantTxnNo,
      raw?.merchantTxnNo,
      raw?.invoiceNo,
      raw?.invoice_no,
      raw?.gateway_order_id,
    ),
    gatewayPaymentId: pickString(
      raw?.txnId,
      raw?.TxnID,
      raw?.txn_id,
      raw?.payment_id,
      raw?.rrn,
      raw?.RRN,
    ),
    gatewaySignature: pickString(
      raw?.secureHash,
      raw?.SecureHash,
      raw?.secure_hash,
      raw?.signature,
    ),
    message: pickString(
      raw?.message,
      raw?.responseMessage,
      raw?.error,
      status === 'success'
        ? 'Payment successful'
        : status === 'cancelled'
          ? 'Payment cancelled'
          : status === 'pending'
            ? 'Payment pending'
            : 'Payment failed',
    ),
  };
};

const normalizePayphiEnv = (value?: string): string => {
  const env = String(value || 'UAT').trim().toUpperCase();
  if (env === 'PROD' || env === 'PRODUCTION' || env === 'LIVE' || env === '1') {
    return 'PROD';
  }
  // Customer SDK expects UAT for sandbox / test
  return 'UAT';
};

export const setPayphiAppInfo = async (info: PayphiAppInfo): Promise<void> => {
  const sdk = loadPayphiSdk();
  if (!sdk) {
    throw new Error(
      'PayPhi native SDK is not linked. Rebuild the app after installing react-native-payphi-sdk.',
    );
  }
  const merchantId = String(info.merchantId || '').trim();
  const appId = String(info.appId || merchantId).trim() || merchantId;
  const environment = normalizePayphiEnv(info.environment);
  const merchantName = String(info.merchantName || 'Ayurmuni').trim() || 'Ayurmuni';

  console.log('[PAYPHI] setAppInfo =>', { environment, merchantId, appId, merchantName });
  await sdk.setAppInfo(environment, merchantId, appId, merchantName);
};

/**
 * Open PayPhi sheet using book-slot `data.icici` fields (passed through to makePayment).
 */
export const openPayphiPayment = async (
  appInfo: PayphiAppInfo | null,
  request: PayphiPaymentRequest,
  timeoutMs = 10 * 60 * 1000,
): Promise<PayphiPaymentResult> => {
  const sdk = loadPayphiSdk();
  if (!sdk || !isPayphiNativeLinked()) {
    const err: any = new Error(
      'PayPhi native SDK is not linked. Run: npx react-native run-android',
    );
    err.code = 'PAYPHI_NATIVE_MISSING';
    throw err;
  }

  if (!appInfo?.merchantId) {
    throw new Error('ICICI payload missing merchantId on data.icici');
  }

  const amount = formatPayphiAmount(request.amount);
  if (!amount) {
    throw new Error('ICICI PayPhi amount is missing or invalid');
  }

  // Let RN finish loading UI so currentActivity is valid (DIALOG needs Activity).
  await waitForUiIdle();

  try {
    await setPayphiAppInfo(appInfo);
  } catch (initError: any) {
    // Soft-fail: some UAT builds still open the sheet after init warning.
    console.log('[PAYPHI] setAppInfo warning =>', initError?.message || initError);
  }

  await waitForUiIdle();

  return new Promise<PayphiPaymentResult>((resolve, reject) => {
    let settled = false;

    const finish = (result: PayphiPaymentResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        subscription?.remove?.();
      } catch {
        // ignore
      }
      resolve(result);
    };

    const onResponse = (payload: any) => {
      console.log('[PAYPHI] payment_response =>', payload);
      finish(mapPayphiResponse(payload));
    };

    let subscription: { remove?: () => void } | null = null;
    try {
      if (typeof sdk.addPaymentResponseListener === 'function') {
        subscription = sdk.addPaymentResponseListener(onResponse);
      }
    } catch (error) {
      reject(error);
      return;
    }

    const timer = setTimeout(() => {
      finish({
        status: 'pending',
        raw: { timeout: true },
        gatewayOrderId: String(request.merchantTxnNo || ''),
        gatewayPaymentId: '',
        gatewaySignature: '',
        message: 'Payment timed out. Please check your order status.',
      });
    }, timeoutMs);

    try {
      const creds = getPayphiCredentials();
      // Only bridge-safe strings (no undefined/null — avoids HostFunction Invalid Parameter!!)
      const payload: Record<string, string> = {
        amount,
        merchantId: String(request.merchantId ?? '').trim(),
        merchantTxnNo: String(request.merchantTxnNo ?? '').trim(),
        currencyCode: String(request.currencyCode || '356').trim(),
        customerEmailID: String(request.customerEmailID ?? '').trim(),
        customerMobileNo: String(request.customerMobileNo ?? '').trim(),
        customerName: String(request.customerName ?? '').trim(),
        addlParam1: String(request.addlParam1 ?? '').trim(),
        addlParam2: String(request.addlParam2 ?? '').trim(),
        aggregatorID: String(
          request.aggregatorID ?? request.aggregatorId ?? creds.aggregatorID ?? '',
        ).trim(),
        apiVersion: String(request.apiVersion || '1.0').trim(),
        transactionType: String(request.transactionType || 'SALE').trim(),
        payType: String(
          request.payType !== undefined && request.payType !== null
            ? request.payType
            : '0',
        ).trim(),
      };
      const secretKey = pickString(
        request.secretKey,
        request.secret_key,
        creds.secretKey,
      );
      // Only explicit SDK secureToken — never initiateSale secureHash
      const secureToken = pickString(request.secureToken, request.SecureToken);
      if (secretKey) payload.secretKey = secretKey;
      if (secureToken) payload.secureToken = secureToken;

      if (!payload.merchantId || !payload.merchantTxnNo || !payload.customerEmailID) {
        throw new Error(
          'ICICI PayPhi needs merchantId, merchantTxnNo and customerEmailID',
        );
      }
      if (!secretKey && !secureToken) {
        throw new Error(
          'ICICI PayPhi needs secretKey (UAT Key) or secureToken to open SDK',
        );
      }

      console.log('[PAYPHI] opening makePayment =>', {
        amount: payload.amount,
        merchantId: payload.merchantId,
        merchantTxnNo: payload.merchantTxnNo,
        currencyCode: payload.currencyCode,
        customerEmailID: payload.customerEmailID,
        aggregatorID: payload.aggregatorID,
        hasSecretKey: Boolean(secretKey),
        hasSecureToken: Boolean(secureToken),
      });

      sdk.makePayment(payload);
    } catch (error) {
      settled = true;
      clearTimeout(timer);
      try {
        subscription?.remove?.();
      } catch {
        // ignore
      }
      reject(error);
    }
  });
};

export const isPayphiUserCancelled = (result: PayphiPaymentResult | any): boolean => {
  if (!result) return false;
  if (result?.status === 'cancelled') return true;
  const msg = String(result?.message ?? result?.description ?? '').toLowerCase();
  return msg.includes('cancel') || msg.includes('closed by user');
};

export const hasPayphiOrder = (data: any): boolean => {
  const gateway = String(data?.payment_gateway ?? data?.gateway ?? '')
    .toLowerCase()
    .replace(/[\s_-]/g, '');
  if (gateway === 'payphi' || gateway === 'icici' || gateway === 'icicipayphi') return true;
  return Boolean(data?.icici || data?.icici_merchant_txn_no);
};

export const payphiGatewayId = (): PaymentGateway => 'icici';

export const buildIciciVerifyPayload = (args: {
  paymentId: string;
  merchantTxnNo: string;
  gatewayPaymentId?: string;
  gatewaySignature?: string;
}): {
  payment_id: string;
  gateway_order_id: string;
  icici_merchant_txn_no: string;
  merchantTxnNo: string;
  payment_gateway: 'icici';
  gateway_payment_id?: string;
  gateway_signature?: string;
} => {
  const merchantTxnNo = String(args.merchantTxnNo || '').trim();
  const body: {
    payment_id: string;
    gateway_order_id: string;
    icici_merchant_txn_no: string;
    merchantTxnNo: string;
    payment_gateway: 'icici';
    gateway_payment_id?: string;
    gateway_signature?: string;
  } = {
    payment_id: String(args.paymentId || '').trim(),
    gateway_order_id: merchantTxnNo,
    icici_merchant_txn_no: merchantTxnNo,
    merchantTxnNo,
    payment_gateway: 'icici',
  };
  const payId = String(args.gatewayPaymentId || '').trim();
  const sig = String(args.gatewaySignature || '').trim();
  if (payId) body.gateway_payment_id = payId;
  if (sig) body.gateway_signature = sig;
  return body;
};

export const resolveIciciMerchantTxnNo = (
  paymentData: any,
  sdkGatewayOrderId?: string,
): string =>
  pickString(
    paymentData?.icici?.merchantTxnNo,
    paymentData?.gateway_order_id,
    paymentData?.icici_merchant_txn_no,
    paymentData?.merchantTxnNo,
    sdkGatewayOrderId,
  );
